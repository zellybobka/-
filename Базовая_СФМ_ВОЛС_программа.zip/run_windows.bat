@echo off
setlocal
call .venv\Scripts\activate
python vols_sfm_app.py
