from __future__ import annotations

import csv
import json
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk


DEFAULT_ROWS = [
    {
        "subsystem": "Оптический кабель",
        "function": "Передача оптического сигнала между узлами связи",
        "requirement": "Соответствие проектной длине и типу волокна",
        "indicator": "Затухание, дБ/км",
        "qmin": "0.00",
        "qmax": "0.35",
        "critical": "Да",
    },
    {
        "subsystem": "Муфты и сварные соединения",
        "function": "Обеспечение неразрывности линии и минимальных потерь",
        "requirement": "Стабильность соединения и защита от внешней среды",
        "indicator": "Потери на соединении, дБ",
        "qmin": "0.00",
        "qmax": "0.10",
        "critical": "Да",
    },
    {
        "subsystem": "Приемо-передающее оборудование",
        "function": "Преобразование электрического сигнала в оптический и обратно",
        "requirement": "Совместимость по скорости и длине волны",
        "indicator": "Скорость передачи, Гбит/с",
        "qmin": "1.00",
        "qmax": "100.00",
        "critical": "Да",
    },
    {
        "subsystem": "Источник питания",
        "function": "Поддержание непрерывной работы активного оборудования",
        "requirement": "Резервирование питания и защита от скачков напряжения",
        "indicator": "Время автономной работы, ч",
        "qmin": "2.00",
        "qmax": "24.00",
        "critical": "Нет",
    },
    {
        "subsystem": "Система мониторинга",
        "function": "Контроль состояния линии и регистрация аварий",
        "requirement": "Оперативное оповещение обслуживающего персонала",
        "indicator": "Время обнаружения отказа, мин",
        "qmin": "0.00",
        "qmax": "5.00",
        "critical": "Нет",
    },
]

TABLE_COLUMNS = (
    "subsystem",
    "function",
    "requirement",
    "indicator",
    "qmin",
    "qmax",
    "critical",
)

TABLE_HEADERS = {
    "subsystem": "Техническая система",
    "function": "Функция",
    "requirement": "Требование / ограничение",
    "indicator": "Показатель качества",
    "qmin": "Qmin",
    "qmax": "Qmax",
    "critical": "Критичный параметр",
}


class SfmApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Базовая СФМ ВОЛС")
        self.root.geometry("1400x760")
        self.rows: list[dict[str, str]] = []
        self.selected_index: int | None = None

        self.object_name = tk.StringVar(value="ВОЛС магистрального сегмента")
        self.vars = {column: tk.StringVar() for column in TABLE_COLUMNS}

        self._build_ui()
        self.load_default_rows()

    def _build_ui(self) -> None:
        self.root.columnconfigure(1, weight=1)
        self.root.rowconfigure(0, weight=1)

        form_frame = ttk.Frame(self.root, padding=16)
        form_frame.grid(row=0, column=0, sticky="nsw")

        table_frame = ttk.Frame(self.root, padding=(0, 16, 16, 16))
        table_frame.grid(row=0, column=1, sticky="nsew")
        table_frame.columnconfigure(0, weight=1)
        table_frame.rowconfigure(2, weight=1)

        ttk.Label(
            form_frame,
            text="Формирование базовой структурно-функциональной модели ВОЛС",
            font=("Segoe UI", 12, "bold"),
            wraplength=320,
        ).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))

        ttk.Label(form_frame, text="Название объекта").grid(row=1, column=0, sticky="w")
        ttk.Entry(form_frame, textvariable=self.object_name, width=42).grid(
            row=2, column=0, columnspan=2, sticky="ew", pady=(0, 12)
        )

        labels = [
            ("subsystem", "Техническая система"),
            ("function", "Функция"),
            ("requirement", "Требование / ограничение"),
            ("indicator", "Показатель качества"),
            ("qmin", "Qmin"),
            ("qmax", "Qmax"),
            ("critical", "Критичный параметр"),
        ]

        row_index = 3
        for key, title in labels:
            ttk.Label(form_frame, text=title).grid(row=row_index, column=0, sticky="w")
            row_index += 1
            widget = ttk.Entry(form_frame, textvariable=self.vars[key], width=42)
            if key in {"function", "requirement"}:
                widget = ttk.Entry(form_frame, textvariable=self.vars[key], width=42)
            widget.grid(row=row_index, column=0, columnspan=2, sticky="ew", pady=(0, 10))
            row_index += 1

        button_frame = ttk.Frame(form_frame)
        button_frame.grid(row=row_index, column=0, columnspan=2, sticky="ew", pady=(8, 8))
        for i in range(2):
            button_frame.columnconfigure(i, weight=1)

        ttk.Button(button_frame, text="Добавить строку", command=self.add_row).grid(
            row=0, column=0, sticky="ew", padx=(0, 6)
        )
        ttk.Button(button_frame, text="Обновить строку", command=self.update_row).grid(
            row=0, column=1, sticky="ew"
        )
        ttk.Button(button_frame, text="Удалить строку", command=self.delete_row).grid(
            row=1, column=0, sticky="ew", padx=(0, 6), pady=(6, 0)
        )
        ttk.Button(button_frame, text="Очистить форму", command=self.clear_form).grid(
            row=1, column=1, sticky="ew", pady=(6, 0)
        )

        file_button_frame = ttk.Frame(form_frame)
        file_button_frame.grid(row=row_index + 1, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        for i in range(2):
            file_button_frame.columnconfigure(i, weight=1)

        ttk.Button(file_button_frame, text="Открыть JSON", command=self.open_json).grid(
            row=0, column=0, sticky="ew", padx=(0, 6)
        )
        ttk.Button(file_button_frame, text="Сохранить JSON", command=self.save_json).grid(
            row=0, column=1, sticky="ew"
        )
        ttk.Button(file_button_frame, text="Экспорт CSV", command=self.export_csv).grid(
            row=1, column=0, sticky="ew", padx=(0, 6), pady=(6, 0)
        )
        ttk.Button(file_button_frame, text="Шаблон по умолчанию", command=self.load_default_rows).grid(
            row=1, column=1, sticky="ew", pady=(6, 0)
        )

        ttk.Label(
            form_frame,
            text="Программа создает базовую СФМ ВОЛС в табличной форме и позволяет сохранить результат.",
            wraplength=320,
            foreground="#4a4a4a",
        ).grid(row=row_index + 2, column=0, columnspan=2, sticky="w", pady=(12, 0))

        ttk.Label(
            table_frame,
            text="Таблица 1. Базовая структурно-функциональная модель ВОЛС",
            font=("Segoe UI", 11, "bold"),
        ).grid(row=0, column=0, sticky="w")

        self.object_label = ttk.Label(
            table_frame,
            text=f"Объект моделирования: {self.object_name.get()}",
        )
        self.object_label.grid(row=1, column=0, sticky="w", pady=(4, 10))

        self.object_name.trace_add("write", self._update_object_name)

        tree_container = ttk.Frame(table_frame)
        tree_container.grid(row=2, column=0, sticky="nsew")
        tree_container.columnconfigure(0, weight=1)
        tree_container.rowconfigure(0, weight=1)

        self.tree = ttk.Treeview(
            tree_container,
            columns=("index",) + TABLE_COLUMNS,
            show="headings",
            height=22,
        )
        self.tree.grid(row=0, column=0, sticky="nsew")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        scrollbar_y = ttk.Scrollbar(tree_container, orient="vertical", command=self.tree.yview)
        scrollbar_y.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=scrollbar_y.set)

        self.tree.heading("index", text="№")
        self.tree.column("index", width=45, anchor="center", stretch=False)

        widths = {
            "subsystem": 180,
            "function": 250,
            "requirement": 280,
            "indicator": 180,
            "qmin": 75,
            "qmax": 75,
            "critical": 110,
        }
        for column in TABLE_COLUMNS:
            self.tree.heading(column, text=TABLE_HEADERS[column])
            anchor = "center" if column in {"qmin", "qmax", "critical"} else "w"
            self.tree.column(column, width=widths[column], anchor=anchor)

    def _update_object_name(self, *_args: object) -> None:
        self.object_label.configure(text=f"Объект моделирования: {self.object_name.get()}")

    def load_default_rows(self) -> None:
        self.rows = [row.copy() for row in DEFAULT_ROWS]
        self.selected_index = None
        self.refresh_tree()
        self.clear_form()

    def refresh_tree(self) -> None:
        self.tree.delete(*self.tree.get_children())
        for index, row in enumerate(self.rows, start=1):
            values = (index,) + tuple(row[column] for column in TABLE_COLUMNS)
            self.tree.insert("", "end", iid=str(index - 1), values=values)

    def current_form_data(self) -> dict[str, str]:
        return {column: self.vars[column].get().strip() for column in TABLE_COLUMNS}

    def validate_row(self, row: dict[str, str]) -> bool:
        required = ("subsystem", "function", "requirement", "indicator", "qmin", "qmax", "critical")
        empty = [field for field in required if not row[field]]
        if empty:
            messagebox.showwarning("Проверка данных", "Заполните все поля строки таблицы.")
            return False

        try:
            qmin = float(row["qmin"].replace(",", "."))
            qmax = float(row["qmax"].replace(",", "."))
        except ValueError:
            messagebox.showwarning("Проверка данных", "Значения Qmin и Qmax должны быть числами.")
            return False

        if qmin > qmax:
            messagebox.showwarning("Проверка данных", "Qmin не может быть больше Qmax.")
            return False
        return True

    def add_row(self) -> None:
        row = self.current_form_data()
        if not self.validate_row(row):
            return
        self.rows.append(row)
        self.refresh_tree()
        self.clear_form()

    def update_row(self) -> None:
        if self.selected_index is None:
            messagebox.showinfo("Изменение строки", "Сначала выберите строку в таблице.")
            return
        row = self.current_form_data()
        if not self.validate_row(row):
            return
        self.rows[self.selected_index] = row
        self.refresh_tree()
        self.tree.selection_set(str(self.selected_index))

    def delete_row(self) -> None:
        if self.selected_index is None:
            messagebox.showinfo("Удаление строки", "Сначала выберите строку в таблице.")
            return
        del self.rows[self.selected_index]
        self.selected_index = None
        self.refresh_tree()
        self.clear_form()

    def clear_form(self) -> None:
        for variable in self.vars.values():
            variable.set("")
        self.tree.selection_remove(self.tree.selection())
        self.selected_index = None

    def on_select(self, _event: object) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        self.selected_index = int(selection[0])
        row = self.rows[self.selected_index]
        for column, value in row.items():
            self.vars[column].set(value)

    def save_json(self) -> None:
        path = filedialog.asksaveasfilename(
            title="Сохранить модель",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")],
        )
        if not path:
            return
        payload = {
            "object_name": self.object_name.get().strip(),
            "rows": self.rows,
        }
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        messagebox.showinfo("Сохранение", "Модель сохранена в JSON-файл.")

    def open_json(self) -> None:
        path = filedialog.askopenfilename(
            title="Открыть модель",
            filetypes=[("JSON files", "*.json")],
        )
        if not path:
            return
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        self.object_name.set(payload.get("object_name", "ВОЛС"))
        self.rows = payload.get("rows", [])
        self.refresh_tree()
        self.clear_form()

    def export_csv(self) -> None:
        path = filedialog.asksaveasfilename(
            title="Экспортировать таблицу",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
        )
        if not path:
            return

        with open(path, "w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.writer(handle, delimiter=";")
            writer.writerow(["Базовая структурно-функциональная модель ВОЛС"])
            writer.writerow(["Объект моделирования", self.object_name.get().strip()])
            writer.writerow([])
            writer.writerow(["№"] + [TABLE_HEADERS[column] for column in TABLE_COLUMNS])
            for index, row in enumerate(self.rows, start=1):
                writer.writerow([index] + [row[column] for column in TABLE_COLUMNS])

        messagebox.showinfo("Экспорт", "Таблица экспортирована в CSV-файл.")


def main() -> None:
    root = tk.Tk()
    ttk.Style().theme_use("clam")
    SfmApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
