@echo off
setlocal
python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
if exist requirements.txt python -m pip install -r requirements.txt
echo Installation completed.
