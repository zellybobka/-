#!/usr/bin/env bash
set -e
source .venv/bin/activate
python vols_sfm_app.py
