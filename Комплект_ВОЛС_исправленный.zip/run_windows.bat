@echo off
setlocal
call .venv\Scripts\activate
python -m streamlit run vols_quality_app.py
