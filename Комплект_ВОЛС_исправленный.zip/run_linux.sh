#!/usr/bin/env bash
set -e
source .venv/bin/activate
python -m streamlit run vols_quality_app.py
