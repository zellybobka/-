from __future__ import annotations

from io import StringIO

import numpy as np
import pandas as pd
import streamlit as st


INDICATORS = [
    {
        "code": "P1",
        "name": "Пропускная способность",
        "unit": "Гбит/с",
        "criterion": "Больше - лучше",
        "group": "Вторая группа",
    },
    {
        "code": "P2",
        "name": "Затухание сигнала",
        "unit": "дБ/км",
        "criterion": "Меньше - лучше",
        "group": "Первая группа",
    },
    {
        "code": "P3",
        "name": "Сквозная задержка",
        "unit": "мс",
        "criterion": "Меньше - лучше",
        "group": "Первая группа",
    },
    {
        "code": "P4",
        "name": "Энергопотребление",
        "unit": "Вт",
        "criterion": "Меньше - лучше",
        "group": "Первая группа",
    },
    {
        "code": "P5",
        "name": "Коэффициент готовности",
        "unit": "доли ед.",
        "criterion": "Больше - лучше",
        "group": "Вторая группа",
    },
    {
        "code": "P6",
        "name": "Запас оптического бюджета",
        "unit": "дБ",
        "criterion": "Больше - лучше",
        "group": "Вторая группа",
    },
]

ROWS = [
    {"№": 1, "Функция": "Передача оптического сигнала", "СП ВОЛС": "Линейная подсистема", "ТС": "Оптический кабель"},
    {"№": 2, "Функция": "Формирование оптического сигнала", "СП ВОЛС": "Передающая подсистема", "ТС": "Оптический передатчик"},
    {"№": 3, "Функция": "Прием оптического сигнала", "СП ВОЛС": "Приемная подсистема", "ТС": "Оптический приемник"},
    {"№": 4, "Функция": "Коммутация и распределение трафика", "СП ВОЛС": "Сетевая подсистема", "ТС": "Коммутатор агрегации"},
    {"№": 5, "Функция": "Контроль состояния линии", "СП ВОЛС": "Подсистема мониторинга", "ТС": "Сервер мониторинга"},
    {"№": 6, "Функция": "Обеспечение электропитания", "СП ВОЛС": "Подсистема электропитания", "ТС": "Источник бесперебойного питания"},
]

VALUE_COLUMNS = [
    "P1 min",
    "P1 max",
    "P2 min",
    "P2 max",
    "P3 min",
    "P3 max",
    "P4 min",
    "P4 max",
    "P5 min",
    "P5 max",
    "P6 min",
    "P6 max",
]

BASE_MODEL = np.array(
    [
        [10, 100, 0.00, 0.30, 0.0, 1.5, 0, 120, 0.985, 1.000, 18, 32],
        [10, 100, 0.00, 0.45, 0.0, 1.2, 0, 45, 0.985, 1.000, 14, 26],
        [10, 100, 0.00, 0.45, 0.0, 1.2, 0, 45, 0.985, 1.000, 14, 26],
        [10, 100, 0.00, 0.00, 0.0, 0.9, 0, 160, 0.990, 1.000, 10, 22],
        [1, 10, 0.00, 0.00, 0.0, 0.7, 0, 90, 0.985, 1.000, 8, 18],
        [0, 0, 0.00, 0.00, 0.0, 0.5, 0, 70, 0.980, 1.000, 6, 12],
    ],
    dtype=float,
)

DEFAULT_REAL_MODELS = {
    "Eltex MES2324P": {
        "description": "Отечественный вариант для региональной магистрали",
        "resources": "не более 610 тыс. руб.",
        "matrix": np.array(
            [
                [10, 25, 0.00, 0.29, 0.0, 1.4, 0, 110, 0.986, 1.000, 18, 24],
                [10, 25, 0.00, 0.42, 0.0, 1.1, 0, 38, 0.986, 1.000, 15, 21],
                [10, 25, 0.00, 0.42, 0.0, 1.1, 0, 38, 0.986, 1.000, 15, 21],
                [10, 25, 0.00, 0.00, 0.0, 0.8, 0, 145, 0.992, 1.000, 11, 19],
                [1, 10, 0.00, 0.00, 0.0, 0.6, 0, 75, 0.987, 1.000, 9, 16],
                [0, 0, 0.00, 0.00, 0.0, 0.4, 0, 62, 0.982, 1.000, 7, 11],
            ],
            dtype=float,
        ),
    },
    "Juniper EX4300": {
        "description": "Корпоративный вариант с повышенным запасом качества",
        "resources": "не более 780 тыс. руб.",
        "matrix": np.array(
            [
                [25, 100, 0.00, 0.27, 0.0, 1.0, 0, 105, 0.992, 1.000, 20, 30],
                [25, 100, 0.00, 0.39, 0.0, 0.9, 0, 34, 0.992, 1.000, 16, 25],
                [25, 100, 0.00, 0.39, 0.0, 0.9, 0, 34, 0.992, 1.000, 16, 25],
                [25, 100, 0.00, 0.00, 0.0, 0.6, 0, 130, 0.996, 1.000, 13, 21],
                [1, 10, 0.00, 0.00, 0.0, 0.4, 0, 68, 0.991, 1.000, 10, 17],
                [0, 0, 0.00, 0.00, 0.0, 0.3, 0, 58, 0.986, 1.000, 8, 12],
            ],
            dtype=float,
        ),
    },
    "Allied Telesis x950": {
        "description": "Высокопроизводительный вариант с избыточным энергопотреблением",
        "resources": "не более 820 тыс. руб.",
        "matrix": np.array(
            [
                [40, 100, 0.00, 0.25, 0.0, 0.9, 0, 118, 0.994, 1.000, 20, 31],
                [40, 100, 0.00, 0.37, 0.0, 0.8, 0, 49, 0.993, 1.000, 17, 27],
                [40, 100, 0.00, 0.37, 0.0, 0.8, 0, 49, 0.993, 1.000, 17, 27],
                [40, 100, 0.00, 0.00, 0.0, 0.5, 0, 178, 0.997, 1.000, 15, 23],
                [1, 10, 0.00, 0.00, 0.0, 0.3, 0, 95, 0.992, 1.000, 10, 18],
                [0, 0, 0.00, 0.00, 0.0, 0.3, 0, 79, 0.987, 1.000, 8, 12],
            ],
            dtype=float,
        ),
    },
}


def apply_windows_xp_theme() -> None:
    st.markdown(
        """
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Tahoma:wght@400;700&display=swap');

        .stApp {
            background:
                linear-gradient(180deg, #5d9df5 0%, #8bbcff 14%, #d8ebff 28%, #eaf4ff 100%);
            color: #0b214a;
            font-family: "Tahoma", "Verdana", sans-serif;
        }

        .block-container {
            padding-top: 1.2rem;
            padding-bottom: 2rem;
        }

        h1, h2, h3, .stMarkdown, label, p, li {
            font-family: "Tahoma", "Verdana", sans-serif !important;
        }

        h1 {
            color: #08336d;
            font-weight: 700;
            background: linear-gradient(180deg, #fdfefe 0%, #dbeafe 100%);
            border: 1px solid #7fa9dc;
            border-radius: 10px;
            padding: 0.7rem 1rem;
            box-shadow: inset 0 1px 0 #ffffff, 0 2px 6px rgba(45, 91, 170, 0.18);
        }

        h3 {
            color: #0f3e7d;
            background: linear-gradient(180deg, #f7fbff 0%, #d8ebff 100%);
            border: 1px solid #8fb0df;
            border-radius: 8px;
            padding: 0.45rem 0.75rem;
        }

        .stAlert, .stMetric, [data-testid="stDataFrame"], [data-testid="stExpander"], [data-testid="stTabs"] {
            border-radius: 8px !important;
        }

        [data-testid="stDataFrame"], [data-testid="stExpander"], div[data-baseweb="select"], .stTextInput > div > div,
        .stDownloadButton, .stButton > button, [data-testid="stMetric"] {
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.95), 0 2px 6px rgba(61, 109, 176, 0.16);
        }

        [data-testid="stExpander"], [data-testid="stDataFrame"], .stTextInput > div > div, div[data-baseweb="select"] > div {
            background: linear-gradient(180deg, #ffffff 0%, #edf5ff 100%);
            border: 1px solid #8faed8 !important;
        }

        .stTabs [data-baseweb="tab-list"] {
            gap: 0.25rem;
        }

        .stTabs [data-baseweb="tab"] {
            background: linear-gradient(180deg, #f5f9ff 0%, #dcecff 100%);
            border: 1px solid #86a8db;
            border-bottom: none;
            border-radius: 8px 8px 0 0;
            color: #12417b;
            padding: 0.45rem 0.85rem;
        }

        .stTabs [aria-selected="true"] {
            background: linear-gradient(180deg, #fffecf 0%, #f3e57b 100%) !important;
            color: #5c3a00 !important;
        }

        .stButton > button, .stDownloadButton > button {
            background: linear-gradient(180deg, #fefefe 0%, #cfe0ff 52%, #b5cdf7 100%);
            border: 1px solid #6e94cc;
            border-radius: 7px;
            color: #0a2d63;
            font-weight: 700;
        }

        .stButton > button:hover, .stDownloadButton > button:hover {
            border-color: #3d74be;
            background: linear-gradient(180deg, #fffde2 0%, #fee78d 100%);
            color: #5d3900;
        }

        .stTextInput input {
            background: #ffffff;
            color: #0b214a;
        }

        [data-testid="stMetric"] {
            background: linear-gradient(180deg, #fffce7 0%, #f7efb0 100%);
            border: 1px solid #ceb95a;
            padding: 0.4rem;
        }

        [data-testid="stSidebar"] {
            background: linear-gradient(180deg, #d7e9ff 0%, #edf6ff 100%);
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def model_to_df(matrix: np.ndarray) -> pd.DataFrame:
    data = []
    for row_meta, row_values in zip(ROWS, matrix, strict=True):
        row = dict(row_meta)
        row.update({column: float(value) for column, value in zip(VALUE_COLUMNS, row_values, strict=True)})
        data.append(row)
    return pd.DataFrame(data)


def df_to_matrix(df: pd.DataFrame) -> np.ndarray:
    numeric = df[VALUE_COLUMNS].apply(pd.to_numeric, errors="coerce")
    if numeric.isna().any().any():
        raise ValueError("Все значения пользовательской модели должны быть числовыми.")
    return numeric.to_numpy(dtype=float)


def matrix_df(matrix: np.ndarray) -> pd.DataFrame:
    return pd.DataFrame(
        matrix,
        index=[f"Строка {index}" for index in range(1, matrix.shape[0] + 1)],
        columns=VALUE_COLUMNS,
    )


def split_quality_matrices(matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    group_1 = np.zeros_like(matrix, dtype=float)
    group_2 = np.zeros_like(matrix, dtype=float)
    for indicator_index, indicator in enumerate(INDICATORS):
        min_col = 2 * indicator_index
        max_col = min_col + 1
        if indicator["criterion"] == "Меньше - лучше":
            group_1[:, max_col] = matrix[:, max_col]
        else:
            group_2[:, min_col] = matrix[:, min_col]
    return group_1, group_2


def weights(rows: int, cols: int) -> np.ndarray:
    total = rows * cols
    denominator = total * (total + 1) / 2
    values = np.arange(total, 0, -1, dtype=float) / denominator
    return values.reshape(rows, cols)


def evaluate_model(base_matrix: np.ndarray, real_matrix: np.ndarray) -> dict[str, object]:
    bq1, bq2 = split_quality_matrices(base_matrix)
    rq1, rq2 = split_quality_matrices(real_matrix)
    cq1 = bq1 - rq1
    cq2 = rq2 - bq2
    cq = cq1 + cq2
    ql = weights(*cq.shape)
    weighted = cq * ql

    failures = []
    negative_positions = np.argwhere(cq < 0)
    for row_index, col_index in negative_positions:
        failures.append(
            {
                "Матрица": "CQ1" if cq1[row_index, col_index] < 0 else "CQ2",
                "Строка": int(row_index + 1),
                "Столбец": VALUE_COLUMNS[col_index],
                "Значение": float(cq[row_index, col_index]),
            }
        )

    compliant = not failures
    qke = float(weighted.sum()) if compliant else None
    return {
        "BQ": base_matrix,
        "BQ1": bq1,
        "BQ2": bq2,
        "RQ": real_matrix,
        "RQ1": rq1,
        "RQ2": rq2,
        "CQ1": cq1,
        "CQ2": cq2,
        "CQ": cq,
        "q_l": ql,
        "q_l*ΔQ_l": weighted,
        "compliant": compliant,
        "failures": failures,
        "Qкэ": qke,
    }


def build_text_report(results: dict[str, dict[str, object]], ranking_df: pd.DataFrame) -> str:
    buffer = StringIO()
    buffer.write("Отчет по оценке качества ВОЛС\n")
    buffer.write("=" * 40 + "\n\n")
    for model_name, result in results.items():
        buffer.write(f"Модель: {model_name}\n")
        buffer.write(f"Соответствие требованиям: {'Да' if result['compliant'] else 'Нет'}\n")
        if result["compliant"]:
            buffer.write(f"Qкэ: {result['Qкэ']:.6f}\n")
        else:
            buffer.write("Qкэ: не рассчитывается\n")
            for failure in result["failures"]:
                buffer.write(
                    f"  - {failure['Матрица']}, строка {failure['Строка']}, "
                    f"столбец {failure['Столбец']}, значение {failure['Значение']:.6f}\n"
                )
        buffer.write("\n")

    buffer.write("Итоговый рейтинг\n")
    if ranking_df.empty:
        buffer.write("Нет моделей, прошедших проверку соответствия.\n")
    else:
        buffer.write(ranking_df.to_string(index=False))
        buffer.write("\n")
    return buffer.getvalue()


def init_state() -> None:
    if "real_models" not in st.session_state:
        st.session_state.real_models = {
            name: {
                "description": config["description"],
                "resources": config["resources"],
                "matrix": config["matrix"].copy(),
            }
            for name, config in DEFAULT_REAL_MODELS.items()
        }
    if "selected_models" not in st.session_state:
        st.session_state.selected_models = list(DEFAULT_REAL_MODELS.keys())


def reset_default_models() -> None:
    st.session_state.real_models = {
        name: {
            "description": config["description"],
            "resources": config["resources"],
            "matrix": config["matrix"].copy(),
        }
        for name, config in DEFAULT_REAL_MODELS.items()
    }
    st.session_state.selected_models = list(DEFAULT_REAL_MODELS.keys())


def render_base_section() -> None:
    st.subheader("1. Базовая «идеальная» модель")
    st.dataframe(model_to_df(BASE_MODEL), use_container_width=True, hide_index=True)


def render_reference_tables() -> None:
    st.subheader("2. Справочник показателей и моделей")
    with st.expander("Показать справочные таблицы", expanded=False):
        st.markdown("**Показатели качества ВОЛС**")
        st.dataframe(pd.DataFrame(INDICATORS), use_container_width=True, hide_index=True)

        models_reference = [
            {
                "№": 1,
                "Модель ВОЛС": "Базовая «идеальная» СФМ ВОЛС",
                "Назначение модели": "Эталонная модель требований",
                "Общий расход ресурсов": "не более 800 тыс. руб.",
            }
        ]
        for index, (name, config) in enumerate(st.session_state.real_models.items(), start=2):
            models_reference.append(
                {
                    "№": index,
                    "Модель ВОЛС": name,
                    "Назначение модели": config["description"],
                    "Общий расход ресурсов": config["resources"],
                }
            )
        st.markdown("**Модели ВОЛС**")
        st.dataframe(pd.DataFrame(models_reference), use_container_width=True, hide_index=True)


def render_model_editor() -> None:
    st.subheader("3. Добавление пользовательской модели")
    model_name = st.text_input("Название пользовательской модели", value="Пользовательская модель")
    description = st.text_input("Назначение модели", value="Пользовательский вариант построения ВОЛС")
    resources = st.text_input("Общий расход ресурсов", value="не более 700 тыс. руб.")

    editable_df = st.data_editor(
        model_to_df(DEFAULT_REAL_MODELS["Eltex MES2324P"]["matrix"]),
        hide_index=True,
        use_container_width=True,
        key="custom_model_editor",
        disabled=["№", "Функция", "СП ВОЛС", "ТС"],
    )

    col_add, col_reset = st.columns(2)
    with col_add:
        if st.button("Добавить модель в расчет", type="primary", use_container_width=True):
            try:
                matrix = df_to_matrix(editable_df)
            except ValueError as error:
                st.error(str(error))
            else:
                clean_name = model_name.strip()
                if not clean_name:
                    st.error("Введите название пользовательской модели.")
                else:
                    st.session_state.real_models[clean_name] = {
                        "description": description.strip() or "Пользовательская модель",
                        "resources": resources.strip() or "не указано",
                        "matrix": matrix,
                    }
                    if clean_name not in st.session_state.selected_models:
                        st.session_state.selected_models.append(clean_name)
                    st.success(f"Модель «{clean_name}» добавлена в расчет.")
    with col_reset:
        if st.button("Вернуть стандартный список моделей", use_container_width=True):
            reset_default_models()
            st.success("Стандартные модели восстановлены.")


def render_selected_models() -> list[str]:
    st.subheader("4. Модели, участвующие в расчете")
    model_names = list(st.session_state.real_models.keys())
    selected = st.multiselect(
        "Выберите модели для расчета",
        options=model_names,
        default=st.session_state.selected_models,
    )
    st.session_state.selected_models = selected

    with st.expander("Просмотр исходных данных выбранных моделей", expanded=False):
        for model_name in selected:
            st.markdown(f"**{model_name}**")
            st.dataframe(
                model_to_df(st.session_state.real_models[model_name]["matrix"]),
                use_container_width=True,
                hide_index=True,
            )
    return selected


def render_base_matrices() -> None:
    st.subheader("5. Базовые матрицы")
    bq1, bq2 = split_quality_matrices(BASE_MODEL)
    ql = weights(*BASE_MODEL.shape)
    tabs = st.tabs(["BQ", "BQ1", "BQ2", "q_l"])
    matrices = [BASE_MODEL, bq1, bq2, ql]
    for tab, matrix in zip(tabs, matrices, strict=True):
        with tab:
            st.dataframe(matrix_df(matrix).round(6), use_container_width=True)


def render_results(selected_models: list[str]) -> tuple[dict[str, dict[str, object]], pd.DataFrame]:
    st.subheader("6. Результаты расчета")
    results: dict[str, dict[str, object]] = {}
    ranking_rows = []

    for model_name in selected_models:
        result = evaluate_model(BASE_MODEL, st.session_state.real_models[model_name]["matrix"])
        results[model_name] = result

        with st.expander(f"Модель: {model_name}", expanded=not result["compliant"]):
            if result["compliant"]:
                st.success("Модель соответствует требованиям.")
                st.metric("Qкэ", f"{result['Qкэ']:.6f}")
            else:
                st.error("Модель не соответствует требованиям и исключается из рейтинга.")
                st.dataframe(pd.DataFrame(result["failures"]), use_container_width=True, hide_index=True)

            tabs = st.tabs(["RQ", "RQ1", "RQ2", "CQ1", "CQ2", "CQ", "q_l·ΔQ_l"])
            names = ["RQ", "RQ1", "RQ2", "CQ1", "CQ2", "CQ", "q_l*ΔQ_l"]
            for tab, name in zip(tabs, names, strict=True):
                with tab:
                    st.dataframe(matrix_df(result[name]).round(6), use_container_width=True)

        if result["compliant"]:
            ranking_rows.append(
                {
                    "Модель": model_name,
                    "Qкэ": result["Qкэ"],
                    "Вывод": "Наиболее качественный вариант",
                }
            )

    ranking_df = pd.DataFrame(ranking_rows)
    if not ranking_df.empty:
        ranking_df = ranking_df.sort_values("Qкэ", ascending=False, ignore_index=True)
        ranking_df.insert(0, "Место", np.arange(1, len(ranking_df) + 1))
        if len(ranking_df) > 1:
            ranking_df.loc[1:, "Вывод"] = "Допустимый вариант с меньшим запасом качества"
    return results, ranking_df


def render_ranking(ranking_df: pd.DataFrame, results: dict[str, dict[str, object]]) -> None:
    st.subheader("7. Итоговый рейтинг")
    if ranking_df.empty:
        st.warning("Нет моделей, прошедших проверку соответствия требованиям.")
    else:
        display_df = ranking_df.copy()
        display_df["Qкэ"] = display_df["Qкэ"].map(lambda value: f"{value:.6f}")
        st.dataframe(display_df, use_container_width=True, hide_index=True)
        st.bar_chart(ranking_df.set_index("Модель")["Qкэ"])

    report = build_text_report(
        results,
        ranking_df if not ranking_df.empty else pd.DataFrame(columns=["Место", "Модель", "Qкэ", "Вывод"]),
    )
    st.download_button(
        "Скачать текстовый отчет",
        data=report.encode("utf-8"),
        file_name="vols_quality_report.txt",
        mime="text/plain",
    )


def main() -> None:
    st.set_page_config(page_title="Моделирование ВОЛС", layout="wide")
    init_state()
    apply_windows_xp_theme()

    st.title("Компьютерное структурно-функциональное моделирование ВОЛС")
    st.caption("Интерфейс расчета качества ВОЛС с визуальным оформлением в стиле Windows XP.")

    render_base_section()
    render_reference_tables()
    render_model_editor()
    selected_models = render_selected_models()
    render_base_matrices()
    results, ranking_df = render_results(selected_models)
    render_ranking(ranking_df, results)


if __name__ == "__main__":
    main()
